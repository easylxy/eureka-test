/**
* Copyright: Copyright(c)2007 Hubei Public Information Industry Co., Ltd. All Rights Reserved. <br>
* Company:湖北公众信息产业有限责任公司
*/
package com.hbgzxx.rest;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class TestController {
	
	@Autowired
    RestTemplate restTemplate;
	
	/**
     * 实例化RestTemplate
     * @return
     */
    @LoadBalanced
    @Bean
    public RestTemplate rest() {
        return new RestTemplate();
    }
	
	/**
     * Rest服务端使用RestTemplate发起http请求,然后得到数据返回给前端----gotoUser是为了区分getUser怕小伙伴晕头
     * @param id
     * @return
     */
    @GetMapping(value = "/gotoUser")
    @ResponseBody
    public Map<String,Object> gotoUser(@RequestParam Integer id){
        Map<String,Object> data = new HashMap<>();
        /**
         * 地址是http://service-provider
         * 不是http://127.0.0.1:10001/
         * 因为他向注册中心注册了服务，服务名称service-provider,我们访问service-provider即可
         */
        data = restTemplate.getForObject("http://service-provider/getUser?id="+id,Map.class);
        return data;
    }

}
