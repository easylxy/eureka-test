/**
* Copyright: Copyright(c)2007 Hubei Public Information Industry Co., Ltd. All Rights Reserved. <br>
* Company:湖北公众信息产业有限责任公司
*/
package com.hbgzxx.feign;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 
 * @Title: <br>
 * @Description: <br>
 * @author: 廖小雨
 * @version: 1.0
 * @date : 2018年12月19日 
 * @comment：Date     Author Version Description 
 *          --------------------------------------------------------
 * 			 2018年12月19日  廖小雨      1.0             创建
 */
@RestController
public class TestFeignController {
	
	@Autowired
	private TestFeignClient testFeignClient;
	
	@GetMapping(value = "/hello")
	public Map hello() {
		return testFeignClient.getUser(0);
	}

}
